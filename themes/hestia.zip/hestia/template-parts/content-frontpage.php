<?php
/**
 * The default template for displaying content
 *
 * Used for frontpage.
 *
 * @package Hestia
 * @since Hestia 1.0
 */
the_content();

